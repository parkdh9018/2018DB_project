create trigger TU_STORE
  after update
  on STORE
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* STORE  CLERK on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00022099", PARENT_OWNER="", PARENT_TABLE="STORE"
    CHILD_OWNER="", CHILD_TABLE="CLERK"
    P2C_VERB_PHRASE="R/64", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_64", FK_COLUMNS="StoreID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.StoreID <> :new.StoreID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM CLERK
      WHERE
        /*  %JoinFKPK(CLERK,:%Old," = "," AND") */
        CLERK.StoreID = :old.StoreID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update STORE because CLERK exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* STORE  RECEIPT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="STORE"
    CHILD_OWNER="", CHILD_TABLE="RECEIPT"
    P2C_VERB_PHRASE="R/102", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_102", FK_COLUMNS="StoreID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.StoreID <> :new.StoreID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM RECEIPT
      WHERE
        /*  %JoinFKPK(RECEIPT,:%Old," = "," AND") */
        RECEIPT.StoreID = :old.StoreID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update STORE because RECEIPT exists.'
      );
    END IF;
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

