create procedure show_emp_info(v_ename in varchar2)
is
v_emp emp%rowtype;
v_dept dept%rowtype;
v_mgrname emp.ename%type;
begin
select empno, ename, job, hiredate, mgr, sal, dname, loc
into v_emp.empno, v_emp.ename, v_emp.job, v_emp.hiredate, v_emp.mgr, v_emp.sal, v_dept.dname, v_dept.loc
from emp, dept
where emp.deptno = dept.deptno and ename = v_ename;
select ename
into v_mgrname
from emp
where empno = v_emp.mgr;
dbms_output.put_line('사원번호 : ' || v_emp.empno);
dbms_output.put_line('사원명 : ' || v_emp.ename);
dbms_output.put_line('직급 : ' || v_emp.job);
dbms_output.put_line('입사일 : ' || v_emp.hiredate);
dbms_output.put_line('관리자명 : ' || v_mgrname);
dbms_output.put_line('급여 : ' || v_emp.sal);
dbms_output.put_line('부서명 : ' || v_dept.dname);
dbms_output.put_line('근무지 : ' || v_dept.loc);
end;
/

