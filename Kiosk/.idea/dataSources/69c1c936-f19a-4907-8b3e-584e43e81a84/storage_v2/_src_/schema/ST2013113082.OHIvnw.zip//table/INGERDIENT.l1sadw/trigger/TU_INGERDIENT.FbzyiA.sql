create trigger TU_INGERDIENT
  after update
  on INGERDIENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* INGERDIENT  FOOD_INGERDIENT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="000264bc", PARENT_OWNER="", PARENT_TABLE="INGERDIENT"
    CHILD_OWNER="", CHILD_TABLE="FOOD_INGERDIENT"
    P2C_VERB_PHRASE="R/6", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_6", FK_COLUMNS="IngredientName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.IngredientName <> :new.IngredientName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM FOOD_INGERDIENT
      WHERE
        /*  %JoinFKPK(FOOD_INGERDIENT,:%Old," = "," AND") */
        FOOD_INGERDIENT.IngredientName = :old.IngredientName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update INGERDIENT because FOOD_INGERDIENT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DISTRIBUTOR_SUPPLIER  INGERDIENT on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="INGERDIENT"
    P2C_VERB_PHRASE="R/10", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_10", FK_COLUMNS="CompanyName" */
  SELECT count(*) INTO NUMROWS
    FROM DISTRIBUTOR_SUPPLIER
    WHERE
      /* %JoinFKPK(:%New,DISTRIBUTOR_SUPPLIER," = "," AND") */
      :new.CompanyName = DISTRIBUTOR_SUPPLIER.CompanyName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update INGERDIENT because DISTRIBUTOR_SUPPLIER does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

