create trigger TD_INGREDIENT
  after delete
  on INGREDIENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* INGREDIENT  FOOD_INGREDIENT on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0000fb3a", PARENT_OWNER="", PARENT_TABLE="INGREDIENT"
    CHILD_OWNER="", CHILD_TABLE="FOOD_INGREDIENT"
    P2C_VERB_PHRASE="R/6", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_6", FK_COLUMNS="IngredientName" */
    SELECT count(*) INTO NUMROWS
      FROM FOOD_INGREDIENT
      WHERE
        /*  %JoinFKPK(FOOD_INGREDIENT,:%Old," = "," AND") */
        FOOD_INGREDIENT.IngredientName = :old.IngredientName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete INGREDIENT because FOOD_INGREDIENT exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

