create trigger TU_ORDERMENU
  after update
  on ORDERMENU
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* ORDERMENU  PAYMENT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00022a42", PARENT_OWNER="", PARENT_TABLE="ORDERMENU"
    CHILD_OWNER="", CHILD_TABLE="PAYMENT"
    P2C_VERB_PHRASE="R/68", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_68", FK_COLUMNS="OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.OrderCode <> :new.OrderCode
  THEN
    SELECT count(*) INTO NUMROWS
      FROM PAYMENT
      WHERE
        /*  %JoinFKPK(PAYMENT,:%Old," = "," AND") */
        PAYMENT.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update ORDERMENU because PAYMENT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* ORDERMENU  SUBORDER on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="ORDERMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/82", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_82", FK_COLUMNS="OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.OrderCode <> :new.OrderCode
  THEN
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update ORDERMENU because SUBORDER exists.'
      );
    END IF;
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

