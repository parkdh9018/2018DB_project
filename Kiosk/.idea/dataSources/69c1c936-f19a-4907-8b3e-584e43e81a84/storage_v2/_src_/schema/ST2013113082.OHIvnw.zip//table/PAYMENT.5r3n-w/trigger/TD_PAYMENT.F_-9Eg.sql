create trigger TD_PAYMENT
  after delete
  on PAYMENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* PAYMENT  CASH on parent delete cascade */
    /* ERWIN_RELATION:CHECKSUM="00028d9d", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="CASH"
    P2C_VERB_PHRASE="is a", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="is_a", FK_COLUMNS="PaymentID""OrderCode" */
    DELETE FROM CASH
      WHERE
        /*  %JoinFKPK(CASH,:%Old," = "," AND") */
        CASH.PaymentID = :old.PaymentID AND
        CASH.OrderCode = :old.OrderCode;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* PAYMENT  CARD on parent delete cascade */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="CARD"
    P2C_VERB_PHRASE="is a", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="is_a", FK_COLUMNS="PaymentID""OrderCode" */
    DELETE FROM CARD
      WHERE
        /*  %JoinFKPK(CARD,:%Old," = "," AND") */
        CARD.PaymentID = :old.PaymentID AND
        CARD.OrderCode = :old.OrderCode;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* PAYMENT  RECEIPT on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="RECEIPT"
    P2C_VERB_PHRASE="R/103", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_103", FK_COLUMNS="PaymentID""OrderCode" */
    SELECT count(*) INTO NUMROWS
      FROM RECEIPT
      WHERE
        /*  %JoinFKPK(RECEIPT,:%Old," = "," AND") */
        RECEIPT.PaymentID = :old.PaymentID AND
        RECEIPT.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete PAYMENT because RECEIPT exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

