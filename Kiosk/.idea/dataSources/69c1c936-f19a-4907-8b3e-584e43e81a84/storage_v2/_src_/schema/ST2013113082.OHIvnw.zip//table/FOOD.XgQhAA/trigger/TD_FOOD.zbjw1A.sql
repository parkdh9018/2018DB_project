create trigger TD_FOOD
  after delete
  on FOOD
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  FOOD_INGREDIENT on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0004aaf3", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="FOOD_INGREDIENT"
    P2C_VERB_PHRASE="R/4", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_4", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM FOOD_INGREDIENT
      WHERE
        /*  %JoinFKPK(FOOD_INGREDIENT,:%Old," = "," AND") */
        FOOD_INGREDIENT.FoodName = :old.FoodName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete FOOD because FOOD_INGREDIENT exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  EVALUATION on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="EVALUATION"
    P2C_VERB_PHRASE="R/13", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_13", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM EVALUATION
      WHERE
        /*  %JoinFKPK(EVALUATION,:%Old," = "," AND") */
        EVALUATION.FoodName = :old.FoodName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete FOOD because EVALUATION exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  SUBITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/75", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_75", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM SUBITEM
      WHERE
        /*  %JoinFKPK(SUBITEM,:%Old," = "," AND") */
        SUBITEM.FoodName = :old.FoodName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete FOOD because SUBITEM exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  SUBORDER on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/78", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_78", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.FoodName = :old.FoodName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete FOOD because SUBORDER exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  SALESITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/86", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_86", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM SALESITEM
      WHERE
        /*  %JoinFKPK(SALESITEM,:%Old," = "," AND") */
        SALESITEM.FoodName = :old.FoodName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete FOOD because SALESITEM exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

