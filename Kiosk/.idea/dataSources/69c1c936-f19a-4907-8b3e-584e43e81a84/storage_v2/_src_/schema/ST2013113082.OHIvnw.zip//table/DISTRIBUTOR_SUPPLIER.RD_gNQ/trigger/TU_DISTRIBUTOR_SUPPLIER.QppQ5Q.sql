create trigger TU_DISTRIBUTOR_SUPPLIER
  after update
  on DISTRIBUTOR_SUPPLIER
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DISTRIBUTOR_SUPPLIER  INGREDIENT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="000260fb", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="INGREDIENT"
    P2C_VERB_PHRASE="R/10", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_10", FK_COLUMNS="CompanyName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.CompanyName <> :new.CompanyName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM INGREDIENT
      WHERE
        /*  %JoinFKPK(INGREDIENT,:%Old," = "," AND") */
        INGREDIENT.CompanyName = :old.CompanyName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update DISTRIBUTOR_SUPPLIER because INGREDIENT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DISTRIBUTOR_SUPPLIER  DRINK on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="DRINK"
    P2C_VERB_PHRASE="R/16", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_16", FK_COLUMNS="CompanyName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.CompanyName <> :new.CompanyName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM DRINK
      WHERE
        /*  %JoinFKPK(DRINK,:%Old," = "," AND") */
        DRINK.CompanyName = :old.CompanyName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update DISTRIBUTOR_SUPPLIER because DRINK exists.'
      );
    END IF;
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

