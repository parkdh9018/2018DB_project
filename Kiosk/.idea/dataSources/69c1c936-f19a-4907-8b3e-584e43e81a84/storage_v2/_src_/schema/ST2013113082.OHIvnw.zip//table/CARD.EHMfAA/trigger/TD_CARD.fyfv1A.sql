create trigger TD_CARD
  after delete
  on CARD
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* CARD  ACCOUNT on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0001017d", PARENT_OWNER="", PARENT_TABLE="CARD"
    CHILD_OWNER="", CHILD_TABLE="ACCOUNT"
    P2C_VERB_PHRASE="R/69", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_69", FK_COLUMNS="PaymentID""OrderCode" */
    SELECT count(*) INTO NUMROWS
      FROM ACCOUNT
      WHERE
        /*  %JoinFKPK(ACCOUNT,:%Old," = "," AND") */
        ACCOUNT.PaymentID = :old.PaymentID AND
        ACCOUNT.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete CARD because ACCOUNT exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

