create procedure InsertEnroll(sStudentId in varchar2,
sCourseId in varchar2,
nCourseIdNo in number,
result out varchar2)
is
too_many_sumCourseUnit exception;
too_many_courses exception;
too_many_students exception;
duplicate_time exception;
nYear number;
nSemester number;
nSumCourseUnit number;
nCourseUnit number;
nCnt number;
nTeachMax number;
cursor overlap
is
select count(*)
from (select t_time
from teach
where t_year = nYear and t_semester = nSemester
and c_id = sCourseId and c_id_no = nCourseIdNo
intersect
select t.t_time
from teach t, enroll e
where e.s_id = sStudentId and e.e_year = nYear
and e.e_semester = nSemester and t.t_year = nYear
and t.t_semester = nSemester and e.c_id = t.c_id
and e.c_id_no = t.c_id_no);
begin
result := '';
dbms_output.put_line('#');
dbms_output.put_line(sStudentId || '님이 과목번호 ' || sCourseId ||
', 분반 ' || to_char(nCourseIdNo) || '의 수강 등록을 요청하였습니다.');
/* 년도, 학기 알아내기 */
nYear := Date2EnrollYear(sysdate);
nSemester := Date2EnrollSemester(sysdate);
/* 에러 처리 1 : 최대학점 초과여부 */
select sum(c.c_unit)
into nSumCourseUnit
from course c, enroll e
where e.s_id = sStudentId and e.e_year = nYear and e.e_semester = nSemester
and e.c_id = c.c_id and e.c_id_no = c.c_id_no;
select c_unit
into nCourseUnit
from course
where c_id = sCourseId and c_id_no = nCourseIdNo;
if(nSumCourseUnit + nCourseUnit > 18) then
raise too_many_sumCourseUnit;
end if;
/* 에러 처리 2 : 동일한 과목 신청 여부 */
select count(*)
into nCnt
from enroll
where s_id = sStudentId and c_id = sCourseId;
if(nCnt > 0) then
raise too_many_courses;
end if;
/* 에러 처리 3 : 수강신청 인원 초과 여부 */
select t_max
into nTeachMax
from teach
where t_year = nYear and t_semester = nSemester and c_id = sCourseId
and c_id_no = nCourseIdNo;
select count(*)
into nCnt
from enroll
where e_year = nYear and e_semester = nSemester
and c_id = sCourseId and c_id_no = nCourseIdNo;
if(nCnt >= nTeachMax) then
raise too_many_students;
end if;
/* 에러 처리 4 : 신청한 과목들 시간 중복 여부 */
open overlap;
fetch overlap
into nCnt;
if(nCnt > 0) then
raise duplicate_time;
end if;
/* 수강 신청 등록 */
insert into enroll(s_id, c_id, c_id_no, e_year, e_semester)
values (sStudentId, sCourseId, nCourseIdNo, nYear, nSemester);
commit;
result := '수강신청 등록이 완료되었습니다.';
exception
when too_many_sumCourseUnit then
result := '최대학점을 초과하였습니다';
when too_many_courses then
result := '이미 등록된 과목을 신청하였습니다';
when too_many_students then
result := '수강신청 인원이 초과되어 등록이 불가능합니다';
when duplicate_time then
result := '이미 등록된 과목 중 중복되는 시간이 존재합니다';
when others then
rollback;
result := sqlcode;
end;
/

