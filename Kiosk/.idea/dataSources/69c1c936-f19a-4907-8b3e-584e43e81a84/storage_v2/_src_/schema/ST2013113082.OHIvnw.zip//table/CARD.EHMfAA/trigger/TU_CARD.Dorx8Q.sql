create trigger TU_CARD
  after update
  on CARD
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* CARD  ACCOUNT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00023619", PARENT_OWNER="", PARENT_TABLE="CARD"
    CHILD_OWNER="", CHILD_TABLE="ACCOUNT"
    P2C_VERB_PHRASE="R/69", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_69", FK_COLUMNS="PaymentID""OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.PaymentID <> :new.PaymentID OR
    :old.OrderCode <> :new.OrderCode
  THEN
    SELECT count(*) INTO NUMROWS
      FROM ACCOUNT
      WHERE
        /*  %JoinFKPK(ACCOUNT,:%Old," = "," AND") */
        ACCOUNT.PaymentID = :old.PaymentID AND
        ACCOUNT.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update CARD because ACCOUNT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* PAYMENT  CARD on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="CARD"
    P2C_VERB_PHRASE="is a", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="is_a", FK_COLUMNS="PaymentID""OrderCode" */
  SELECT count(*) INTO NUMROWS
    FROM PAYMENT
    WHERE
      /* %JoinFKPK(:%New,PAYMENT," = "," AND") */
      :new.PaymentID = PAYMENT.PaymentID AND
      :new.OrderCode = PAYMENT.OrderCode;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update CARD because PAYMENT does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

