create trigger TU_PAYMENT
  after update
  on PAYMENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* PAYMENT  CASH on parent update cascade */
  /* ERWIN_RELATION:CHECKSUM="0004814d", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="CASH"
    P2C_VERB_PHRASE="is a", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="is_a", FK_COLUMNS="PaymentID""OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.PaymentID <> :new.PaymentID OR
    :old.OrderCode <> :new.OrderCode
  THEN
    UPDATE CASH
      SET
        /*  %JoinFKPK(CASH,:%New," = ",",") */
        CASH.PaymentID = :new.PaymentID,
        CASH.OrderCode = :new.OrderCode
      WHERE
        /*  %JoinFKPK(CASH,:%Old," = "," AND") */
        CASH.PaymentID = :old.PaymentID AND
        CASH.OrderCode = :old.OrderCode;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* PAYMENT  CARD on parent update cascade */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="CARD"
    P2C_VERB_PHRASE="is a", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="is_a", FK_COLUMNS="PaymentID""OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.PaymentID <> :new.PaymentID OR
    :old.OrderCode <> :new.OrderCode
  THEN
    UPDATE CARD
      SET
        /*  %JoinFKPK(CARD,:%New," = ",",") */
        CARD.PaymentID = :new.PaymentID,
        CARD.OrderCode = :new.OrderCode
      WHERE
        /*  %JoinFKPK(CARD,:%Old," = "," AND") */
        CARD.PaymentID = :old.PaymentID AND
        CARD.OrderCode = :old.OrderCode;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* PAYMENT  RECEIPT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="RECEIPT"
    P2C_VERB_PHRASE="R/103", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_103", FK_COLUMNS="PaymentID""OrderCode" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.PaymentID <> :new.PaymentID OR
    :old.OrderCode <> :new.OrderCode
  THEN
    SELECT count(*) INTO NUMROWS
      FROM RECEIPT
      WHERE
        /*  %JoinFKPK(RECEIPT,:%Old," = "," AND") */
        RECEIPT.PaymentID = :old.PaymentID AND
        RECEIPT.OrderCode = :old.OrderCode;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update PAYMENT because RECEIPT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* ORDERMENU  PAYMENT on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="ORDERMENU"
    CHILD_OWNER="", CHILD_TABLE="PAYMENT"
    P2C_VERB_PHRASE="R/68", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_68", FK_COLUMNS="OrderCode" */
  SELECT count(*) INTO NUMROWS
    FROM ORDERMENU
    WHERE
      /* %JoinFKPK(:%New,ORDERMENU," = "," AND") */
      :new.OrderCode = ORDERMENU.OrderCode;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update PAYMENT because ORDERMENU does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

