create trigger TU_RECEIPT
  after update
  on RECEIPT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* STORE  RECEIPT on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00021ef3", PARENT_OWNER="", PARENT_TABLE="STORE"
    CHILD_OWNER="", CHILD_TABLE="RECEIPT"
    P2C_VERB_PHRASE="R/102", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_102", FK_COLUMNS="StoreID" */
  SELECT count(*) INTO NUMROWS
    FROM STORE
    WHERE
      /* %JoinFKPK(:%New,STORE," = "," AND") */
      :new.StoreID = STORE.StoreID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update RECEIPT because STORE does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* PAYMENT  RECEIPT on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="PAYMENT"
    CHILD_OWNER="", CHILD_TABLE="RECEIPT"
    P2C_VERB_PHRASE="R/103", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_103", FK_COLUMNS="PaymentID""OrderCode" */
  SELECT count(*) INTO NUMROWS
    FROM PAYMENT
    WHERE
      /* %JoinFKPK(:%New,PAYMENT," = "," AND") */
      :new.PaymentID = PAYMENT.PaymentID AND
      :new.OrderCode = PAYMENT.OrderCode;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update RECEIPT because PAYMENT does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

