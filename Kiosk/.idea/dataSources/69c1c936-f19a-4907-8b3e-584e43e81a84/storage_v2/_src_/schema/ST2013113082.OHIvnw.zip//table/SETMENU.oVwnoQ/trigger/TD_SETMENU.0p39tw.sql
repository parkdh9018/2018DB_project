create trigger TD_SETMENU
  after delete
  on SETMENU
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* SETMENU  SUBITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0002dd21", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/72", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_72", FK_COLUMNS="SetMenuID" */
    SELECT count(*) INTO NUMROWS
      FROM SUBITEM
      WHERE
        /*  %JoinFKPK(SUBITEM,:%Old," = "," AND") */
        SUBITEM.SetMenuID = :old.SetMenuID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete SETMENU because SUBITEM exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* SETMENU  SUBORDER on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/79", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_79", FK_COLUMNS="SetMenuID" */
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.SetMenuID = :old.SetMenuID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete SETMENU because SUBORDER exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* SETMENU  SALESITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/87", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_87", FK_COLUMNS="SetMenuID" */
    SELECT count(*) INTO NUMROWS
      FROM SALESITEM
      WHERE
        /*  %JoinFKPK(SALESITEM,:%Old," = "," AND") */
        SALESITEM.SetMenuID = :old.SetMenuID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete SETMENU because SALESITEM exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

