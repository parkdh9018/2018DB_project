create trigger TU_INGREDIENT
  after update
  on INGREDIENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* INGREDIENT  FOOD_INGREDIENT on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="000264bc", PARENT_OWNER="", PARENT_TABLE="INGREDIENT"
    CHILD_OWNER="", CHILD_TABLE="FOOD_INGREDIENT"
    P2C_VERB_PHRASE="R/6", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_6", FK_COLUMNS="IngredientName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.IngredientName <> :new.IngredientName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM FOOD_INGREDIENT
      WHERE
        /*  %JoinFKPK(FOOD_INGREDIENT,:%Old," = "," AND") */
        FOOD_INGREDIENT.IngredientName = :old.IngredientName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update INGREDIENT because FOOD_INGREDIENT exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DISTRIBUTOR_SUPPLIER  INGREDIENT on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="INGREDIENT"
    P2C_VERB_PHRASE="R/10", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_10", FK_COLUMNS="CompanyName" */
  SELECT count(*) INTO NUMROWS
    FROM DISTRIBUTOR_SUPPLIER
    WHERE
      /* %JoinFKPK(:%New,DISTRIBUTOR_SUPPLIER," = "," AND") */
      :new.CompanyName = DISTRIBUTOR_SUPPLIER.CompanyName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update INGREDIENT because DISTRIBUTOR_SUPPLIER does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

