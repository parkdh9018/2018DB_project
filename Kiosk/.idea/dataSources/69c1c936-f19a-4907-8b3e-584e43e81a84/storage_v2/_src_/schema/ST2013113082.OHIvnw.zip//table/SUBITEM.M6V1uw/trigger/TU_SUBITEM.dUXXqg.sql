create trigger TU_SUBITEM
  after update
  on SUBITEM
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* SETMENU  SUBITEM on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="0002f9c0", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/72", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_72", FK_COLUMNS="SetMenuID" */
  SELECT count(*) INTO NUMROWS
    FROM SETMENU
    WHERE
      /* %JoinFKPK(:%New,SETMENU," = "," AND") */
      :new.SetMenuID = SETMENU.SetMenuID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBITEM because SETMENU does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* FOOD  SUBITEM on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/75", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_75", FK_COLUMNS="FoodName" */
  SELECT count(*) INTO NUMROWS
    FROM FOOD
    WHERE
      /* %JoinFKPK(:%New,FOOD," = "," AND") */
      :new.FoodName = FOOD.FoodName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBITEM because FOOD does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DRINK  SUBITEM on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/76", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_76", FK_COLUMNS="DrinkName" */
  SELECT count(*) INTO NUMROWS
    FROM DRINK
    WHERE
      /* %JoinFKPK(:%New,DRINK," = "," AND") */
      :new.DrinkName = DRINK.DrinkName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBITEM because DRINK does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

