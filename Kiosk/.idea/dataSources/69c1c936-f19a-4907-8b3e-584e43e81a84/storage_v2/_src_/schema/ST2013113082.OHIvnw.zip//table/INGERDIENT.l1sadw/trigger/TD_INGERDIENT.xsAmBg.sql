create trigger TD_INGERDIENT
  after delete
  on INGERDIENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* INGERDIENT  FOOD_INGERDIENT on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0000fb3a", PARENT_OWNER="", PARENT_TABLE="INGERDIENT"
    CHILD_OWNER="", CHILD_TABLE="FOOD_INGERDIENT"
    P2C_VERB_PHRASE="R/6", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_6", FK_COLUMNS="IngredientName" */
    SELECT count(*) INTO NUMROWS
      FROM FOOD_INGERDIENT
      WHERE
        /*  %JoinFKPK(FOOD_INGERDIENT,:%Old," = "," AND") */
        FOOD_INGERDIENT.IngredientName = :old.IngredientName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete INGERDIENT because FOOD_INGERDIENT exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

