create trigger TD_SALESITEM
  after delete
  on SALESITEM
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* SALESITEM  SUBORDER on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0000e0e9", PARENT_OWNER="", PARENT_TABLE="SALESITEM"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/90", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_90", FK_COLUMNS="CouponID" */
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.CouponID = :old.CouponID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete SALESITEM because SUBORDER exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

