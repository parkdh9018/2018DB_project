create trigger TD_DRINK
  after delete
  on DRINK
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* DRINK  SUBITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0002ce91", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/76", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_76", FK_COLUMNS="DrinkName" */
    SELECT count(*) INTO NUMROWS
      FROM SUBITEM
      WHERE
        /*  %JoinFKPK(SUBITEM,:%Old," = "," AND") */
        SUBITEM.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete DRINK because SUBITEM exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* DRINK  SUBORDER on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/80", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_80", FK_COLUMNS="DrinkName" */
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete DRINK because SUBORDER exists.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* DRINK  SALESITEM on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/88", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_88", FK_COLUMNS="DrinkName" */
    SELECT count(*) INTO NUMROWS
      FROM SALESITEM
      WHERE
        /*  %JoinFKPK(SALESITEM,:%Old," = "," AND") */
        SALESITEM.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete DRINK because SALESITEM exists.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

