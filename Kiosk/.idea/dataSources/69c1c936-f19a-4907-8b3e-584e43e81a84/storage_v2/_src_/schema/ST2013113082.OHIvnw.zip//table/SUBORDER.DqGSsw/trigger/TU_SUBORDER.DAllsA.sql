create trigger TU_SUBORDER
  after update
  on SUBORDER
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* FOOD  SUBORDER on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="0005201d", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/78", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_78", FK_COLUMNS="FoodName" */
  SELECT count(*) INTO NUMROWS
    FROM FOOD
    WHERE
      /* %JoinFKPK(:%New,FOOD," = "," AND") */
      :new.FoodName = FOOD.FoodName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBORDER because FOOD does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* SETMENU  SUBORDER on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/79", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_79", FK_COLUMNS="SetMenuID" */
  SELECT count(*) INTO NUMROWS
    FROM SETMENU
    WHERE
      /* %JoinFKPK(:%New,SETMENU," = "," AND") */
      :new.SetMenuID = SETMENU.SetMenuID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBORDER because SETMENU does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DRINK  SUBORDER on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/80", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_80", FK_COLUMNS="DrinkName" */
  SELECT count(*) INTO NUMROWS
    FROM DRINK
    WHERE
      /* %JoinFKPK(:%New,DRINK," = "," AND") */
      :new.DrinkName = DRINK.DrinkName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBORDER because DRINK does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* ORDERMENU  SUBORDER on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="ORDERMENU"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/82", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_82", FK_COLUMNS="OrderCode" */
  SELECT count(*) INTO NUMROWS
    FROM ORDERMENU
    WHERE
      /* %JoinFKPK(:%New,ORDERMENU," = "," AND") */
      :new.OrderCode = ORDERMENU.OrderCode;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBORDER because ORDERMENU does not exist.'
    );
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* SALESITEM  SUBORDER on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="SALESITEM"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/90", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_90", FK_COLUMNS="CouponID" */
  SELECT count(*) INTO NUMROWS
    FROM SALESITEM
    WHERE
      /* %JoinFKPK(:%New,SALESITEM," = "," AND") */
      :new.CouponID = SALESITEM.CouponID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update SUBORDER because SALESITEM does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

