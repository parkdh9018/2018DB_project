create trigger TU_CLERK
  after update
  on CLERK
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* STORE  CLERK on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="0000f2a6", PARENT_OWNER="", PARENT_TABLE="STORE"
    CHILD_OWNER="", CHILD_TABLE="CLERK"
    P2C_VERB_PHRASE="R/64", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_64", FK_COLUMNS="StoreID" */
  SELECT count(*) INTO NUMROWS
    FROM STORE
    WHERE
      /* %JoinFKPK(:%New,STORE," = "," AND") */
      :new.StoreID = STORE.StoreID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update CLERK because STORE does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

