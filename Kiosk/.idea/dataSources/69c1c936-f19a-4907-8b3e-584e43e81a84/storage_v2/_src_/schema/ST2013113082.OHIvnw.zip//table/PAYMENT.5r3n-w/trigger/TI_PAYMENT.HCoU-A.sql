create trigger TI_PAYMENT
  before insert
  on PAYMENT
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* ORDERMENU  PAYMENT on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0001017c", PARENT_OWNER="", PARENT_TABLE="ORDERMENU"
    CHILD_OWNER="", CHILD_TABLE="PAYMENT"
    P2C_VERB_PHRASE="R/68", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_68", FK_COLUMNS="OrderCode" */
    SELECT count(*) INTO NUMROWS
      FROM ORDERMENU
      WHERE
        /* %JoinFKPK(:%New,ORDERMENU," = "," AND") */
        :new.OrderCode = ORDERMENU.OrderCode;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */

      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert PAYMENT because ORDERMENU does not exist.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

