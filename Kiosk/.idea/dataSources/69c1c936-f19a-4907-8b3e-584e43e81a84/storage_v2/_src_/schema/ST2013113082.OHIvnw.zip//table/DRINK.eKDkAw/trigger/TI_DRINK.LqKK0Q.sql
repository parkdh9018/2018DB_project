create trigger TI_DRINK
  before insert
  on DRINK
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* DISTRIBUTOR_SUPPLIER  DRINK on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0001160b", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="DRINK"
    P2C_VERB_PHRASE="R/16", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_16", FK_COLUMNS="CompanyName" */
    SELECT count(*) INTO NUMROWS
      FROM DISTRIBUTOR_SUPPLIER
      WHERE
        /* %JoinFKPK(:%New,DISTRIBUTOR_SUPPLIER," = "," AND") */
        :new.CompanyName = DISTRIBUTOR_SUPPLIER.CompanyName;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */

      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert DRINK because DISTRIBUTOR_SUPPLIER does not exist.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

