create trigger TI_SALESITEM
  before insert
  on SALESITEM
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* FOOD  SALESITEM on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="00031365", PARENT_OWNER="", PARENT_TABLE="FOOD"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/86", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_86", FK_COLUMNS="FoodName" */
    SELECT count(*) INTO NUMROWS
      FROM FOOD
      WHERE
        /* %JoinFKPK(:%New,FOOD," = "," AND") */
        :new.FoodName = FOOD.FoodName;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */

      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert SALESITEM because FOOD does not exist.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* SETMENU  SALESITEM on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="SETMENU"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/87", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_87", FK_COLUMNS="SetMenuID" */
    SELECT count(*) INTO NUMROWS
      FROM SETMENU
      WHERE
        /* %JoinFKPK(:%New,SETMENU," = "," AND") */
        :new.SetMenuID = SETMENU.SetMenuID;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */

      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert SALESITEM because SETMENU does not exist.'
      );
    END IF;

    /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
    /* DRINK  SALESITEM on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/88", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_88", FK_COLUMNS="DrinkName" */
    SELECT count(*) INTO NUMROWS
      FROM DRINK
      WHERE
        /* %JoinFKPK(:%New,DRINK," = "," AND") */
        :new.DrinkName = DRINK.DrinkName;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */

      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert SALESITEM because DRINK does not exist.'
      );
    END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

