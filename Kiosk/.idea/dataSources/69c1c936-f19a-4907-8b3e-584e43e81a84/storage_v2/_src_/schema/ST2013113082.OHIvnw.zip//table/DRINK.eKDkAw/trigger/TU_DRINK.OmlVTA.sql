create trigger TU_DRINK
  after update
  on DRINK
  for each row
  DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DRINK  SUBITEM on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00047019", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBITEM"
    P2C_VERB_PHRASE="R/76", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_76", FK_COLUMNS="DrinkName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.DrinkName <> :new.DrinkName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM SUBITEM
      WHERE
        /*  %JoinFKPK(SUBITEM,:%Old," = "," AND") */
        SUBITEM.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update DRINK because SUBITEM exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DRINK  SUBORDER on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SUBORDER"
    P2C_VERB_PHRASE="R/80", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_80", FK_COLUMNS="DrinkName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.DrinkName <> :new.DrinkName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM SUBORDER
      WHERE
        /*  %JoinFKPK(SUBORDER,:%Old," = "," AND") */
        SUBORDER.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update DRINK because SUBORDER exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DRINK  SALESITEM on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DRINK"
    CHILD_OWNER="", CHILD_TABLE="SALESITEM"
    P2C_VERB_PHRASE="R/88", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_88", FK_COLUMNS="DrinkName" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.DrinkName <> :new.DrinkName
  THEN
    SELECT count(*) INTO NUMROWS
      FROM SALESITEM
      WHERE
        /*  %JoinFKPK(SALESITEM,:%Old," = "," AND") */
        SALESITEM.DrinkName = :old.DrinkName;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20005,
        'Cannot update DRINK because SALESITEM exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53 */
  /* DISTRIBUTOR_SUPPLIER  DRINK on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="DISTRIBUTOR_SUPPLIER"
    CHILD_OWNER="", CHILD_TABLE="DRINK"
    P2C_VERB_PHRASE="R/16", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_16", FK_COLUMNS="CompanyName" */
  SELECT count(*) INTO NUMROWS
    FROM DISTRIBUTOR_SUPPLIER
    WHERE
      /* %JoinFKPK(:%New,DISTRIBUTOR_SUPPLIER," = "," AND") */
      :new.CompanyName = DISTRIBUTOR_SUPPLIER.CompanyName;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */

    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update DRINK because DISTRIBUTOR_SUPPLIER does not exist.'
    );
  END IF;


-- ERwin Builtin 2018년 12월 8일 토요일 오후 5:01:53
END;
/

